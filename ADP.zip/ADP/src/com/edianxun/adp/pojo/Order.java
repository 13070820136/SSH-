package com.edianxun.adp.pojo;

import javax.persistence.*;

/**
 * Created by yu on 2017/6/20.
 */
@Entity
@Table(name = "order")
public class Order {
    @Id
    @Column(name = "orderid")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderid;
    private int customerid;
    @Column(name = "customer_name")
    private String customerName;
    private int creatime;
    private int status;

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public int getCustomerid() {
        return customerid;
    }

    public void setCustomerid(int customerid) {
        this.customerid = customerid;
    }

    public String getCutomerName() {
        return customerName;
    }

    public void setCutomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCreatime() {
        return creatime;
    }

    public void setCreatime(int creatime) {
        this.creatime = creatime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
