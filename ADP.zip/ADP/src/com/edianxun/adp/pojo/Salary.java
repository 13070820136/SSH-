package com.edianxun.adp.pojo;

import javax.persistence.*;

/**
 * Created by yu on 2017/6/8.
 */
@Entity
@Table(name = "salary")
public class Salary {
    @Id
    @Column(name = "salaryid")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int salaryid;
    private int managerId;
    private String name;
    @Column(name = "base_pay")
    private int basePay;
    @Column(name = "exam_day")
    private int examDay;
    private String post;
    private String level;
    private int performance;
    @Column(name = "full_time")
    private int fullTime;
    @Column(name = "lunch_subsidy")
    private int lunchSubsidy;

    public int getCreateTime() {
        return createTime;
    }

    public void setCreateTime(int createTime) {
        this.createTime = createTime;
    }

    @Column(name = "create_time")
    private int createTime;

    public int getSalaryid() {
        return salaryid;
    }

    public void setSalaryid(int salaryid) {
        this.salaryid = salaryid;
    }

    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBasePay() {
        return basePay;
    }

    public void setBasePay(int basePay) {
        this.basePay = basePay;
    }

    public int getExamDay() {
        return examDay;
    }

    public void setExamDay(int examDay) {
        this.examDay = examDay;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getPerformance() {
        return performance;
    }

    public void setPerformance(int performance) {
        this.performance = performance;
    }

    public int getFullTime() {
        return fullTime;
    }

    public void setFullTime(int fullTime) {
        this.fullTime = fullTime;
    }

    public int getLunchSubsidy() {
        return lunchSubsidy;
    }

    public void setLunchSubsidy(int lunchSubsidy) {
        this.lunchSubsidy = lunchSubsidy;
    }
}
