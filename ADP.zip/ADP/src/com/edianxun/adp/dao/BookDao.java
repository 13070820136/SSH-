package com.edianxun.adp.dao;

import com.edianxun.adp.pojo.Book;
import com.edianxun.adp.pojo.Customer;

import java.util.List;

/**
 * Created by yu on 2017/6/3.
 */
public interface BookDao extends BaseDao<Book> {

    int getMaxNumFromBook(int day);

    Book getBookByDayAndCustomer(int day, int cid, int status);

    List<Book> getBookTradeList(int customerid, int status);

    List<Book> findAllByTime(int startTime,int endTime);

}
