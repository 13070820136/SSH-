package com.edianxun.adp.dao;

import com.edianxun.adp.pojo.Comment;
import com.edianxun.adp.pojo.Order;

/**
 * Created by yu on 2017/6/3.
 */
public interface CommentDao extends BaseDao<Comment>{

}
