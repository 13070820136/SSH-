package com.edianxun.adp.dao;

import com.edianxun.adp.pojo.GateCard;
import com.edianxun.adp.pojo.Salary;

import java.util.List;

/**
 * 管理员操作接口
 * @author lhr
 * @ date 2014-4-21
 */
public interface SalaryDao extends BaseDao<Salary> {

    List<Salary> findAllOrderbyDay();

}
