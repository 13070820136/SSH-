package com.edianxun.adp.dao.impl;

import com.edianxun.adp.dao.CommentDao;
import com.edianxun.adp.dao.OrderDao;
import com.edianxun.adp.pojo.Comment;
import com.edianxun.adp.pojo.Order;

/**
 * @author lhr
 * @ date 2014-4-21
 */
public class CommentDaoImpl extends BaseDaoImpl<Comment> implements CommentDao {

}
