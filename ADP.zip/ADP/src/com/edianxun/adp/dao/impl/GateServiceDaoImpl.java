package com.edianxun.adp.dao.impl;

import com.edianxun.adp.dao.GateDao;
import com.edianxun.adp.dao.GateServiceDao;
import com.edianxun.adp.pojo.GateCard;
import com.edianxun.adp.pojo.GateService;

import java.util.List;

/**
 * Created by yu on 2017/6/22.
 */
public class GateServiceDaoImpl extends BaseDaoImpl<GateService> implements GateServiceDao {
    @Override
    public List<GateService> findAllGateService() {
        List gateServices = find("from GateService");
        if (gateServices != null) {
            return (List<GateService>) gateServices;
        }
        return null;
    }
}
