package com.edianxun.adp.dao.impl;

import com.edianxun.adp.dao.GateDao;
import com.edianxun.adp.dao.SalaryDao;
import com.edianxun.adp.pojo.GateCard;
import com.edianxun.adp.pojo.Salary;

import java.util.List;

/**
 * @author lhr
 * @ date 2014-4-21
 */
public class SalaryDaoImpl extends BaseDaoImpl<Salary> implements SalaryDao {

    @Override
    public List<Salary> findAllOrderbyDay() {
        List salaries = find("from Salary order by createTime desc");
        if (salaries != null) {
            return (List<Salary>) salaries;
        }
        return null;
    }

}
