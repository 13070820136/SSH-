package com.edianxun.adp.dao.impl;

import com.edianxun.adp.dao.CustomerDao;
import com.edianxun.adp.dao.ManagerDao;
import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.pojo.Manager;

import java.util.List;

/**
 * @author lhr
 * @ date 2014-4-21
 */
public class CustomerDaoImpl extends BaseDaoImpl<Customer> implements CustomerDao {

    @Override
    public Customer findManagerByNameAndPwd(String name, String pwd) {
        List customers = find("select m from Customer m where m.account=?0 and m.password=?1", name, pwd);
        if (customers != null && customers.size() >= 1) {
            return (Customer) customers.get(0);
        }
        return null;
    }

}
