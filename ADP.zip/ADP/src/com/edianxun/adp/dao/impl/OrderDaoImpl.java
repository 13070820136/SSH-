package com.edianxun.adp.dao.impl;

import com.edianxun.adp.dao.CustomerDao;
import com.edianxun.adp.dao.OrderDao;
import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.pojo.Order;

import java.util.List;

/**
 * @author lhr
 * @ date 2014-4-21
 */
public class OrderDaoImpl extends BaseDaoImpl<Order> implements OrderDao {

}
