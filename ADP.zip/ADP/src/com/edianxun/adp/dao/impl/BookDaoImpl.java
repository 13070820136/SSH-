package com.edianxun.adp.dao.impl;

import com.edianxun.adp.dao.BookDao;
import com.edianxun.adp.dao.CustomerDao;
import com.edianxun.adp.pojo.Book;
import com.edianxun.adp.pojo.Customer;

import java.util.List;

/**
 * @author lhr
 * @ date 2014-4-21
 */
public class BookDaoImpl extends BaseDaoImpl<Book> implements BookDao {
    @Override
    public int getMaxNumFromBook(int day) {
        List<Book> numbers = find("from Book where day = ?0 and status=0 order by number desc limit 0,1", day);
        if (numbers.size() > 0) {
            return numbers.get(0).getNumber();
        }
        return 0;
    }

    @Override
    public Book getBookByDayAndCustomer(int day, int cid) {
        List<Book> numbers = find("from Book where day = ?0 and status=0 and customer_id = ?1", day, cid);
        if (numbers.size() > 0) {
            return numbers.get(0);
        }
        return null;
    }
}
