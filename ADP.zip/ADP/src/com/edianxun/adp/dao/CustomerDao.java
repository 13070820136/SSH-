package com.edianxun.adp.dao;

import com.edianxun.adp.pojo.Customer;

/**
 * Created by yu on 2017/6/3.
 */
public interface CustomerDao extends BaseDao<Customer>{

    Customer findManagerByNameAndPwd(String name, String pwd);

}
