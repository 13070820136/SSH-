package com.edianxun.adp.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.service.CustomerService;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.edianxun.adp.pojo.Book;
import com.edianxun.adp.service.BookService;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Created by yu on 2017/6/12.
 */
@Results({@Result(name = "book", location = "/page/book.jsp", type = "dispatcher")})
public class BookAction extends BaseAction
        implements ModelDriven<Book> {

    private static final long serialVersionUID = -1040088992400395429L;
    private static final Logger logger = Logger.getLogger(ManagerAction.class);
    private Book book = new Book();
    private BookService bookService;
    private CustomerService customerService;
    private String name;

    public void setBookService(BookService bookService) {
        this.bookService = bookService;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Action("book")
    public String book() {
        Map<String, Object> session = getSession();
        try {
            int customerId = session.get("customerId") != null ? Integer.parseInt(session.get("customerId").toString()) : -1;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            int day = Integer.parseInt(sdf.format(new Date(System.currentTimeMillis())));
            int number = bookService.getMaxNumFromBook(day);
            getRequest().getSession().setAttribute("number", number);
            Book book = bookService.getBookByDayAndCustomer(day, customerId);
            if (book != null) {
                getRequest().getSession().setAttribute("book", book);
            }
        } catch (Exception e) {
            logger.debug("customer login exception");
            e.printStackTrace();
        }
        return "book";
    }

    @Action("getNumber")
    public void getNumber() {
        Map<String, Object> session = getSession();
        try {
            int customerId = session.get("customerId") != null ? Integer.parseInt(session.get("customerId").toString()) : -1;
            String loginname = session.get("loginname") != null ? session.get("loginname").toString() : "";
            if (customerId == -1) {
                this.outJson(103 + "");
                return;
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Date now = new Date(System.currentTimeMillis());
            int day = Integer.parseInt(sdf.format(now));
            int number = bookService.getMaxNumFromBook(day);
            Book book = new Book();
            book.setNumber(number + 1);
            book.setDay(day);
            book.setCreateTime((int) (now.getTime() / 1000));
            book.setCustomerId(customerId);
            book.setCustomerName(loginname);
            book.setStatus(0);
            int newNum = bookService.saveBook(book);
            this.outJson(newNum + "");
        } catch (Exception e) {
            logger.debug("customer login exception");
            this.outJson(102 + "");
            e.printStackTrace();
        }
    }

    @Action("pay")
    public String pay() {
        Map<String, Object> session = getSession();
        try {
            int customerId = session.get("customerId") != null ? Integer.parseInt(session.get("customerId").toString()) : -1;
            Customer customer = customerService.getCustomer(customerId);
            int bookid = getRequest().getParameter("bookid") != null ? Integer.parseInt(getRequest().getParameter("bookid").toString()) : -1;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            int day = Integer.parseInt(sdf.format(new Date(System.currentTimeMillis())));
            Book book = bookService.getBookByDayAndCustomer(day, customerId);
            if (book != null && customer != null && customer.getAmount() < book.getPay()) {
                this.outJson(102 + "");
            } else {
                //支付
                //修改余额
                customer.setAmount(customer.getAmount() - book.getPay());
                customerService.update(customer);
                //修改book表状态

            }

        } catch (Exception e) {
            logger.debug("customer login exception");
            e.printStackTrace();
        }
        return "book";
    }

    @Override
    public Book getModel() {
        return book;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
