package com.edianxun.adp.action;
/**
 * @author lhr
 * @date 2014-4-30
 */

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.edianxun.adp.pojo.GateCard;
import com.edianxun.adp.pojo.Salary;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.edianxun.adp.pojo.Manager;
import com.edianxun.adp.service.ManagerService;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.struts2.interceptor.ParameterAware;

@Results({@Result(name = "main", location = "/jsp/main.jsp", type = "redirect")})
public class ManagerAction extends BaseAction
        implements ModelDriven<Object>, ParameterAware {

    private static final long serialVersionUID = -1040088992400395429L;
    private static final Logger logger = Logger.getLogger(ManagerAction.class);
    private Manager manager = new Manager();
    private GateCard gateCard = new GateCard();
    private Salary salary = new Salary();
    private ManagerService managerService;
    private String name;

    public void setManagerService(ManagerService managerService) {
        this.managerService = managerService;
    }

    public String execute() {
        logger.debug("bingo");
        return SUCCESS;
    }

    @Action("mgrlogin")
    public String login() {
        Map<String, Object> session = getSession();
        try {
            int managerId = managerService.loginValidate(manager);
            logger.debug("manager Id :" + managerId);
            if (managerId > 0) {
                session.put("managerId", managerId);
                session.put("manager", manager.getName());
            } else {
                return LOGIN;
            }
        } catch (Exception e) {
            logger.debug("manager login exception");
            e.printStackTrace();
        }
        return "main";
    }

    @Action("mgrlogout")
    public String logout() {
        logger.debug("logout");
        Map<String, Object> session = getSession();
        session.remove("managerId");
        session.remove("manager");
        return null;
    }

    @Action("mgrlist")
    public void list() {
        logger.debug("query all manager");
        try {
            this.outJson(managerService.managerList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Action("mgradd")
    public void add() {
        try {
            manager.setStatus("NORMAL");
            manager.setCreateTime((int) (new Date().getTime()/ 1000));
            int managerId = managerService.addManager(manager);
            logger.debug("managerId : " + managerId);
            if (managerId <= 0) {

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Action("mgrupdate")
    public void update() {
        logger.debug("manager update password ...");
        try {
            Map<String, Object> session = getSession();
            int id = (Integer) session.get("managerId");
            Manager man = managerService.getManager(id);
            man.setPassword(manager.getPassword());
            managerService.update(man);
            this.outJson(man.getPassword());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Action("mgrUpdateInfo")
    public void updateInfo() {
        logger.debug("manager update info ...");
        try {
            System.out.println("####" + manager.getDescrition());
            manager.setCreateTime((int) (new Date().getTime()/ 1000));
            managerService.update(manager);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Action("mgrdel")
    public void del() {
        logger.debug("manager delete");
        try {
            managerService.del(manager.getManagerId());
            this.outJson("ok");
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("nok");
        }
    }

    @Action("gatelist")
    public void gatelist() {
        logger.debug("query all manager");
        try {
            this.outJson(managerService.gateList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Action("gatedel")
    public void gatedel() {
        logger.debug("gatecard delete");
        try {
            managerService.gatedel(gateCard.getGateid());
            this.outJson("ok");
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("nok");
        }
    }

    @Action("gateupdate")
    public void gateupdate() {
        logger.debug("gatecard update password ...");
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Long timestamp = Long.parseLong(gateCard.getGoTime() + "") * 1000;
            Date date = new Date(timestamp);
            gateCard.setDay(Integer.parseInt(sdf.format(date)));
            managerService.gateupdate(gateCard);
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("102");
        }
    }

    @Action("gateAdd")
    public void gateAdd() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            Long timestamp = Long.parseLong(gateCard.getGoTime() + "") * 1000;
            Date date = new Date(timestamp);
            gateCard.setDay(Integer.parseInt(sdf.format(date)));
            int gateid = managerService.addGate(gateCard);
            logger.debug("gateid : " + gateid);
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("102");
        }
    }

    @Action("salarylist")
    public void salarylist() {
        logger.debug("query all salary");
        try {
            this.outJson(managerService.salaryList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Action("salayAdd")
    public void salayAdd() {
        try {
            salary.setCreateTime((int) (new Date().getTime() / 1000));
            salary.setBasePay(salary.getBasePay() * 100);
            salary.setFullTime(salary.getFullTime() * 100);
            salary.setLunchSubsidy(salary.getLunchSubsidy() * 100);
            salary.setPerformance(salary.getPerformance() * 100);
            int salaryid = managerService.addSalary(salary);
            logger.debug("salaryid : " + salaryid);
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("102");
        }
    }

    @Action("salayDel")
    public void salayDel() {
        logger.debug("salary delete");
        try {
            managerService.delSalary(salary);
            this.outJson("ok");
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("nok");
        }
    }

    @Action("sqlaryupdate")
    public void sqlaryupdate() {
        logger.debug("salary update password ...");
        try {
            salary.setCreateTime((int) (new Date().getTime() / 1000));
            salary.setBasePay(salary.getBasePay() * 100);
            salary.setFullTime(salary.getFullTime() * 100);
            salary.setLunchSubsidy(salary.getLunchSubsidy() * 100);
            salary.setPerformance(salary.getPerformance() * 100);
            managerService.updateSalary(salary);
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("102");
        }
    }

    private Map<String, String[]> parameters;

    @Override
    public void setParameters(Map<String, String[]> parameters) {
        this.parameters = parameters;
    }

    @Override
    public Object getModel() {
        if (parameters.get("goTime") != null || parameters.get("gateid") != null) {
            return gateCard;
        } else if (parameters.get("basePay") != null || parameters.get("salaryid") != null) {
            return salary;
        } else {
            return manager;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
