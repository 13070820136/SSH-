package com.edianxun.adp.action;
/**
 * @author lhr
 * @date 2014-4-30
 */

import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.service.CustomerService;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import java.util.Date;
import java.util.Map;

@Results({@Result(name = "index", location = "page/select_service.jsp", type = "redirect")})
public class ServiceAction extends BaseAction
        implements ModelDriven<Customer> {

    private static final long serialVersionUID = -1040088992400395429L;
    private static final Logger logger = Logger.getLogger(ManagerAction.class);
    private Customer customer = new Customer();
    private CustomerService customerService;
    private String name;

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Action("serviceindex")
    public String index() {

        return "index";
    }

    @Override
    public Customer getModel() {
        return customer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
