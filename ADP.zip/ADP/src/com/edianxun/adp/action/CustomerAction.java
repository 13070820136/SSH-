package com.edianxun.adp.action;
/**
 * @author lhr
 * @date 2014-4-30
 */

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.service.CustomerService;
import com.opensymphony.xwork2.ModelDriven;

@Results({@Result(name = "index", location = "index.jsp", type = "redirect")})
public class CustomerAction extends BaseAction
        implements ModelDriven<Customer> {

    private static final long serialVersionUID = -1040088992400395429L;
    private static final Logger logger = Logger.getLogger(ManagerAction.class);
    private Customer customer = new Customer();
    private CustomerService customerService;
    private String name;

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Action("customerlogin")
    public void login() {
        Map<String, Object> session = getSession();
        try {
            int customerId = customerService.loginValidate(customer);
            logger.debug("customer Id :" + customerId);
            if (customerId > 0) {
                session.put("customerId", customerId);
                session.put("loginname", customer.getAccount());
            } else {
                this.outJson("102");
            }
        } catch (Exception e) {
            logger.debug("customer login exception");
            e.printStackTrace();
        }
    }

    @Action("loginout")
    public String loginout() {
        logger.debug("logout");
        Map<String, Object> session = getSession();
        session.remove("customerId");
        session.remove("loginname");
        return "index";
    }

    @Action("customerList")
    public void list() {
        logger.debug("query all customer");
        try {
            this.outJson(customerService.customerList());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Action("customerAdd")
    public void add() {
        try {
            customer.setStatus("NORMAL");
            Date now = new Date();
            customer.setCreateTime((int) (now.getTime() / 1000));
            int customerId = customerService.addCustomer(customer);
            logger.debug("customerId : " + customerId);
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("102");
        }
    }

    @Action("customerUpdateInfo")
    public void updateInfo() {
        logger.debug("customer update info ...");
        try {
            Date now = new Date();
            customer.setCreateTime((int) (now.getTime() / 1000));
            customerService.update(customer);
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("102");
        }
    }

    @Action("customerDel")
    public void del() {
        logger.debug("manager delete");
        try {
            customerService.delCustomer(customer.getCustomerid());
            this.outJson("ok");
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("nok");
        }
    }

    @Action("customerInfo")
    public void info() {
        Map<String, Object> session = getSession();
        try {
            int customerId = session.get("customerId") != null ? Integer.parseInt(session.get("customerId").toString()) : -1;
            Customer customer = customerService.getCustomer(customerId);
            if (customer!=null){
                this.outJson(new java.text.DecimalFormat("#.00").format((double)(customer.getAmount())/100));
            }
        } catch (Exception e) {
            e.printStackTrace();
            this.outJson("-1");
        }
    }

    @Override
    public Customer getModel() {
        return customer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
