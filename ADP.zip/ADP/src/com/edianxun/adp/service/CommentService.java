package com.edianxun.adp.service;

import com.edianxun.adp.pojo.Comment;
import com.edianxun.adp.pojo.Order;

public interface CommentService {

	/**
	 * 新增订单
	 * @param comment
	 * @return 返回新用户主键
	 * @throws Exception
	 */
	int addComment(Comment comment) throws Exception;

}
