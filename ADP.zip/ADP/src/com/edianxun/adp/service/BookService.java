package com.edianxun.adp.service;

import com.edianxun.adp.pojo.Book;

import java.util.List;

/**
 * Created by yu on 2017/6/12.
 */
public interface BookService {

    int getMaxNumFromBook(int day);

    int saveBook(Book book);

    Book getBookByDayAndCustomer(int day, int cid, int status);

    void updateStatus(int bookid, int status);

    List<Book> getBookTradeList(int customerid,int status);

    String reportList() throws Exception;

    String reportList(int startTime,int endTime) throws Exception;

}
