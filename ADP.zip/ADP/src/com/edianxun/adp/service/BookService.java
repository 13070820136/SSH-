package com.edianxun.adp.service;

import com.edianxun.adp.pojo.Book;

/**
 * Created by yu on 2017/6/12.
 */
public interface BookService {

    int getMaxNumFromBook(int day);

    int saveBook(Book book);

    Book getBookByDayAndCustomer(int day, int cid);

    void updateStatus(int bookid,int status);
}
