package com.edianxun.adp.service;

import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.pojo.Order;

public interface OrderService {

	/**
	 * 新增订单
	 * @param order
	 * @return 返回新用户主键
	 * @throws Exception
	 */
	int addOrder(Order order) throws Exception;

}
