package com.edianxun.adp.service;

import com.edianxun.adp.pojo.GateCard;
import com.edianxun.adp.pojo.Manager;
import com.edianxun.adp.pojo.Salary;

public interface ManagerService {

    /**
     * 新增管理员
     *
     * @param manager
     * @return 返回新用户主键
     * @throws Exception
     */
    int addManager(Manager manager) throws Exception;

    /**
     * 验证用户登录
     *
     * @param manager
     * @return
     * @throws Exception
     */
    int loginValidate(Manager manager) throws Exception;

    /**
     * 验证用户名是否存在
     *
     * @param name
     * @return
     * @throws Exception
     */
    boolean validateName(String name) throws Exception;

    String managerList() throws Exception;

    Manager getManager(Integer managerId) throws Exception;

    void update(Manager manager) throws Exception;

    void del(Integer id) throws Exception;

    String gateList() throws Exception;

    void gatedel(Integer id) throws Exception;

    public void gateupdate(GateCard gateCard) throws Exception;

    public int addGate(GateCard gateCard) throws Exception;

    String salaryList() throws Exception;

    public int addSalary(Salary salary) throws Exception;

    public int delSalary(Salary salary) throws Exception;

    public void updateSalary(Salary salary) throws Exception;

}
