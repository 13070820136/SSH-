package com.edianxun.adp.service.impl;

import com.edianxun.adp.dao.BookDao;
import com.edianxun.adp.pojo.Book;
import com.edianxun.adp.service.BookService;

/**
 * Created by yu on 2017/6/12.
 */
public class BookServiceImpl implements BookService {

    private BookDao bookDao;

    public void setBookDao(BookDao bookDao) {
        this.bookDao = bookDao;
    }

    @Override
    public int getMaxNumFromBook(int day) {
        return bookDao.getMaxNumFromBook(day);
    }

    @Override
    public int saveBook(Book book) {
        bookDao.save(book);
        return getMaxNumFromBook(book.getDay());
    }

    @Override
    public Book getBookByDayAndCustomer(int day,int cid) {
        return bookDao.getBookByDayAndCustomer(day,cid);
    }
}
