package com.edianxun.adp.service.impl;

import com.edianxun.adp.dao.BookDao;
import com.edianxun.adp.pojo.Book;
import com.edianxun.adp.service.BookService;
import com.sun.org.apache.xpath.internal.operations.Bool;
import net.sf.json.JSONArray;

import java.util.List;

/**
 * Created by yu on 2017/6/12.
 */
public class BookServiceImpl implements BookService {

    private BookDao bookDao;

    public void setBookDao(BookDao bookDao) {
        this.bookDao = bookDao;
    }

    @Override
    public int getMaxNumFromBook(int day) {
        return bookDao.getMaxNumFromBook(day);
    }

    @Override
    public int saveBook(Book book) {
        bookDao.save(book);
        return getMaxNumFromBook(book.getDay());
    }

    @Override
    public Book getBookByDayAndCustomer(int day, int cid, int status) {
        return bookDao.getBookByDayAndCustomer(day, cid, status);
    }

    @Override
    public void updateStatus(int bookid, int status) {
        Book book = bookDao.get(Book.class, bookid);
        book.setStatus(status);
        bookDao.update(book);
    }

    @Override
    public List<Book> getBookTradeList(int customerid, int status) {
        return bookDao.getBookTradeList(customerid, status);
    }

    @Override
    public String reportList() throws Exception {
        String listJson = null;
        try {
            List<Book> list = bookDao.findAll(Book.class);
            if (list.size() != 0) {
                String lJson = JSONArray.fromObject(list).toString();
                Long total = bookDao.allTotal(Book.class);
                listJson = "{\"total\":" + total + ",\"rows\":" + lJson + "}";
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("query all book exception");
        }
        return listJson;
    }

    @Override
    public String reportList(int startTime, int endTime) throws Exception {
        String listJson = null;
        try {
            List<Book> list = bookDao.findAllByTime(startTime,endTime);
                String lJson = JSONArray.fromObject(list).toString();
                Long total = bookDao.allTotal(Book.class);
                listJson = "{\"total\":" + total + ",\"rows\":" + lJson + "}";
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("query all book exception");
        }
        return listJson;
    }

}
