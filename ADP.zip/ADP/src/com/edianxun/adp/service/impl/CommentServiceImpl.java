package com.edianxun.adp.service.impl;

import com.edianxun.adp.dao.CommentDao;
import com.edianxun.adp.dao.OrderDao;
import com.edianxun.adp.pojo.Comment;
import com.edianxun.adp.pojo.Order;
import com.edianxun.adp.service.CommentService;
import com.edianxun.adp.service.OrderService;

public class CommentServiceImpl implements CommentService {

    private CommentDao commentDao; //spring 注入
    public void setCommentDao(CommentDao commentDao) {
        this.commentDao = commentDao;
    }

    @Override
    public int addComment(Comment comment) throws Exception {
        commentDao.save(comment);
        return comment.getCommentid();
    }
}
