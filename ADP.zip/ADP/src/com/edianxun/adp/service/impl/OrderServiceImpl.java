package com.edianxun.adp.service.impl;

import com.edianxun.adp.dao.CustomerDao;
import com.edianxun.adp.dao.OrderDao;
import com.edianxun.adp.pojo.Customer;
import com.edianxun.adp.pojo.Order;
import com.edianxun.adp.service.CustomerService;
import com.edianxun.adp.service.OrderService;
import net.sf.json.JSONArray;

import java.util.List;

public class OrderServiceImpl implements OrderService {

    private OrderDao orderDao; //spring 注入
    public void setOrderDao(OrderDao orderDao) {
        this.orderDao = orderDao;
    }

    @Override
    public int addOrder(Order order) throws Exception {
        orderDao.save(order);
        return order.getOrderid();
    }

}
