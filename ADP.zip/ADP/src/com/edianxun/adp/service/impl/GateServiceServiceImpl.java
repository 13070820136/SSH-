package com.edianxun.adp.service.impl;

import com.edianxun.adp.dao.GateServiceDao;
import com.edianxun.adp.pojo.GateService;
import com.edianxun.adp.service.GateServiceService;

import java.util.List;

/**
 * Created by yu on 2017/6/22.
 */
public class GateServiceServiceImpl implements GateServiceService {

    GateServiceDao gateServiceDao = null;

    public void setGateServiceDao(GateServiceDao gateServiceDao) {
        this.gateServiceDao = gateServiceDao;
    }

    @Override
    public List<GateService> getAllGate() {
        return gateServiceDao.findAllGateService();
    }

}
