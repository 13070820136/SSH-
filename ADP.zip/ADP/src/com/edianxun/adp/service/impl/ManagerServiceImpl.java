package com.edianxun.adp.service.impl;

import java.util.List;

import com.edianxun.adp.dao.GateDao;
import com.edianxun.adp.dao.SalaryDao;
import com.edianxun.adp.pojo.GateCard;
import com.edianxun.adp.pojo.Salary;
import net.sf.json.JSONArray;

import com.edianxun.adp.dao.ManagerDao;
import com.edianxun.adp.pojo.Manager;
import com.edianxun.adp.service.ManagerService;

public class ManagerServiceImpl implements ManagerService {
	
	private ManagerDao managerDao; //spring 注入
	public void setManagerDao(ManagerDao managerDao) {
		this.managerDao = managerDao;
	}
	private GateDao gateDao; //spring 注入
	public void setGateDao(GateDao gateDao) {
		this.gateDao = gateDao;
	}
	private SalaryDao salaryDao; //spring 注入
	public void setSalaryDao(SalaryDao salaryDao) {
		this.salaryDao = salaryDao;
	}

	@Override
	public int addManager(Manager manager) throws Exception {
		try {
			managerDao.save(manager);
			return manager.getManagerId();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("add manager exception");
		}
	}

	@Override
	public int loginValidate(Manager manager) throws Exception {
		try {
			Manager man = managerDao.findManagerByNameAndPwd(manager.getName(), 
					manager.getPassword());
			if (man != null) {
				return man.getManagerId();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("login validate exception");
		}
		return -1;
	}

	@Override
	public boolean validateName(String name) throws Exception {
		try {
			Manager manager = managerDao.findManagerByName(name);
			if (manager != null) {
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("validate manager name exception");
		}
	}
	
	@Override
	public String managerList() throws Exception {
		String listJson = null;
		try {
			List<Manager> list = managerDao.findAll(Manager.class);
			if (list.size() != 0) {
				String lJson = JSONArray.fromObject(list).toString();
				Long total = managerDao.allTotal(Manager.class);
				listJson = "{\"total\":"+total+",\"rows\":"+lJson+"}";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("query all manager exception");
		}
		return listJson;
	}
	@Override
	public void update(Manager manager) throws Exception {
		try {
			managerDao.update(manager);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("update manager exception");
		}
		
	}
	@Override
	public Manager getManager(Integer managerId) throws Exception {
		try {
			Manager manager = managerDao.get(Manager.class, managerId);
			return manager;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("get manager exception");
		}
	}
	@Override
	public void del(Integer id) throws Exception {
		try {
			managerDao.delete(Manager.class, id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("delete manager exception");
		}
		
	}

	@Override
	public String gateList() throws Exception {
		String listJson = null;
		try {
			List<GateCard> list = gateDao.findAllOrderbyDay();
			if (list.size() != 0) {
				String lJson = JSONArray.fromObject(list).toString();
				Long total = gateDao.allTotal(GateCard.class);
				listJson = "{\"total\":"+total+",\"rows\":"+lJson+"}";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("query all gate card exception");
		}
		return listJson;
	}

	@Override
	public void gatedel(Integer id) throws Exception {
		try {
			gateDao.delete(GateCard.class, id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("delete gate exception");
		}
	}
	@Override
	public void gateupdate(GateCard gateCard) throws Exception {
		try {
			gateDao.update(gateCard);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("update gate exception");
		}

	}
	@Override
	public int addGate(GateCard gateCard) throws Exception {
		try {
			gateDao.save(gateCard);
			return gateCard.getGateid();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("add gate exception");
		}
	}
	@Override
	public String salaryList() throws Exception {
		String listJson = null;
		try {
			List<Salary> list = salaryDao.findAllOrderbyDay();
			if (list.size() != 0) {
				String lJson = JSONArray.fromObject(list).toString();
				Long total = salaryDao.allTotal(Salary.class);
				listJson = "{\"total\":"+total+",\"rows\":"+lJson+"}";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("query all salary card exception");
		}
		return listJson;
	}

	@Override
	public int addSalary(Salary salary) throws Exception {
		try {
			salaryDao.save(salary);
			return salary.getSalaryid();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("add gate exception");
		}
	}

	@Override
	public int delSalary(Salary salary) throws Exception {
		try {
			salaryDao.delete(salary);
			return salary.getSalaryid();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("add gate exception");
		}
	}

	@Override
	public void updateSalary(Salary salary) throws Exception {
		try {
			salaryDao.update(salary);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("update gate exception");
		}
	}

}
