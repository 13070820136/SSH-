package com.edianxun.adp.service;

import com.edianxun.adp.pojo.GateService;

import java.util.List;

/**
 * Created by yu on 2017/6/22.
 */
public interface GateServiceService {
    List<GateService> getAllGate();
}
